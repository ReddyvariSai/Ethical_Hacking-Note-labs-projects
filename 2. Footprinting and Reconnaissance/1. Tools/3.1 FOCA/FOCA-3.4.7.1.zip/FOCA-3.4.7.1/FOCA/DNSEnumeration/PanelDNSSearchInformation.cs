using System.Windows.Forms;

namespace FOCA
{
    /// <summary>
    /// DNS Search information panel
    /// </summary>
    public partial class PanelDNSSearchInformation : UserControl
    {
        public PanelDNSSearchInformation()
        {
            InitializeComponent();
        }
    }
}