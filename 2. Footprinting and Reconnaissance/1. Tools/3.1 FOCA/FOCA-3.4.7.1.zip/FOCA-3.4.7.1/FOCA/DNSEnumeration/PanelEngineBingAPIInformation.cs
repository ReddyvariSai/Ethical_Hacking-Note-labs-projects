using System.Windows.Forms;

namespace FOCA
{
    /// <summary>
    /// Bing API limitations information panel
    /// </summary>
    public partial class PanelEngineBingAPIInformation : UserControl
    {
        public PanelEngineBingAPIInformation()
        {
            InitializeComponent();
        }
    }
}