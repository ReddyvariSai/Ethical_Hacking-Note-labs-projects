using System.Windows.Forms;

namespace FOCA
{
    /// <summary>
    /// Bing Web limitations information panel
    /// </summary>
    public partial class PanelEngineBingWebInformation : UserControl
    {
        public PanelEngineBingWebInformation()
        {
            InitializeComponent();
        }
    }
}