using System.Windows.Forms;

namespace FOCA
{
    /// <summary>
    /// Google API limitations information panel
    /// </summary>
    public partial class PanelEngineGoogleAPIInformation : UserControl
    {
        public PanelEngineGoogleAPIInformation()
        {
            InitializeComponent();
        }
    }
}