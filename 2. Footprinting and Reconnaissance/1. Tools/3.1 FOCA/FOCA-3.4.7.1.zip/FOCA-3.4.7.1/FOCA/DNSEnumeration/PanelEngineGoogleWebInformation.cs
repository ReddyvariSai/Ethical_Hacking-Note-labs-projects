using System.Windows.Forms;

namespace FOCA
{
    /// <summary>
    /// Google Web limitations information panel
    /// </summary>
    public partial class PanelEngineGoogleWebInformation : UserControl
    {
        public PanelEngineGoogleWebInformation()
        {
            InitializeComponent();
        }
    }
}