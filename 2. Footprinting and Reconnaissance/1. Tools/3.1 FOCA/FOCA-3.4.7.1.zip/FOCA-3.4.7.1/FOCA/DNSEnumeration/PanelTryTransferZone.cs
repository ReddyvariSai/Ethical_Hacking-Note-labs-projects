using System.Windows.Forms;

namespace FOCA
{
    /// <summary>
    ///     The program tries to make a DNS Transfer Zone to find new subdomains.
    ///     This action may be ilegal in some countries.
    /// </summary>
    public partial class PanelTryTransferZone : UserControl
    {
        public PanelTryTransferZone()
        {
            InitializeComponent();
        }
    }
}