namespace FOCA
{
    partial class FormAbout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAbout));
            this.pictureBoxAdvert = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelInfo = new System.Windows.Forms.Panel();
            this.linkLabel10 = new System.Windows.Forms.LinkLabel();
            this.picFOCA = new System.Windows.Forms.PictureBox();
            this.linkLabel9 = new System.Windows.Forms.LinkLabel();
            this.buttonShodan = new System.Windows.Forms.Button();
            this.linkLabel8 = new System.Windows.Forms.LinkLabel();
            this.labelBuild = new System.Windows.Forms.Label();
            this.labelBuildl = new System.Windows.Forms.Label();
            this.labelVersion = new System.Windows.Forms.Label();
            this.labelVersionl = new System.Windows.Forms.Label();
            this.linkLabel7 = new System.Windows.Forms.LinkLabel();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.lblResearchers = new System.Windows.Forms.Label();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBoxLicence = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.picAbout = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAdvert)).BeginInit();
            this.panel2.SuspendLayout();
            this.panelInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFOCA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAbout)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxAdvert
            // 
            this.pictureBoxAdvert.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxAdvert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxAdvert.ErrorImage = null;
            this.pictureBoxAdvert.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBoxAdvert.InitialImage = null;
            this.pictureBoxAdvert.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxAdvert.Name = "pictureBoxAdvert";
            this.pictureBoxAdvert.Size = new System.Drawing.Size(297, 97);
            this.pictureBoxAdvert.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxAdvert.TabIndex = 28;
            this.pictureBoxAdvert.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.panelInfo);
            this.panel2.Controls.Add(this.textBoxLicence);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 102);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(514, 343);
            this.panel2.TabIndex = 77;
            // 
            // panelInfo
            // 
            this.panelInfo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panelInfo.Controls.Add(this.linkLabel10);
            this.panelInfo.Controls.Add(this.picFOCA);
            this.panelInfo.Controls.Add(this.linkLabel9);
            this.panelInfo.Controls.Add(this.buttonShodan);
            this.panelInfo.Controls.Add(this.linkLabel8);
            this.panelInfo.Controls.Add(this.labelBuild);
            this.panelInfo.Controls.Add(this.labelBuildl);
            this.panelInfo.Controls.Add(this.labelVersion);
            this.panelInfo.Controls.Add(this.labelVersionl);
            this.panelInfo.Controls.Add(this.linkLabel7);
            this.panelInfo.Controls.Add(this.linkLabel6);
            this.panelInfo.Controls.Add(this.linkLabel5);
            this.panelInfo.Controls.Add(this.lblResearchers);
            this.panelInfo.Controls.Add(this.linkLabel3);
            this.panelInfo.Controls.Add(this.linkLabel2);
            this.panelInfo.Controls.Add(this.linkLabel1);
            this.panelInfo.Controls.Add(this.linkLabel4);
            this.panelInfo.Controls.Add(this.panel3);
            this.panelInfo.Location = new System.Drawing.Point(4, 0);
            this.panelInfo.Name = "panelInfo";
            this.panelInfo.Size = new System.Drawing.Size(506, 208);
            this.panelInfo.TabIndex = 0;
            // 
            // linkLabel10
            // 
            this.linkLabel10.AutoSize = true;
            this.linkLabel10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel10.Location = new System.Drawing.Point(290, 192);
            this.linkLabel10.Name = "linkLabel10";
            this.linkLabel10.Size = new System.Drawing.Size(114, 13);
            this.linkLabel10.TabIndex = 105;
            this.linkLabel10.TabStop = true;
            this.linkLabel10.Tag = "anolla@informatica64.com";
            this.linkLabel10.Text = "Alejandro Nolla Blanco";
            // 
            // picFOCA
            // 
            this.picFOCA.BackColor = System.Drawing.SystemColors.Control;
            this.picFOCA.Image = ((System.Drawing.Image)(resources.GetObject("picFOCA.Image")));
            this.picFOCA.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.picFOCA.Location = new System.Drawing.Point(35, 25);
            this.picFOCA.Name = "picFOCA";
            this.picFOCA.Size = new System.Drawing.Size(183, 100);
            this.picFOCA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picFOCA.TabIndex = 104;
            this.picFOCA.TabStop = false;
            // 
            // linkLabel9
            // 
            this.linkLabel9.AutoSize = true;
            this.linkLabel9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel9.Location = new System.Drawing.Point(291, 170);
            this.linkLabel9.Name = "linkLabel9";
            this.linkLabel9.Size = new System.Drawing.Size(107, 13);
            this.linkLabel9.TabIndex = 103;
            this.linkLabel9.TabStop = true;
            this.linkLabel9.Tag = "dromero@informatica64.com";
            this.linkLabel9.Text = "Daniel Romero Pérez";
            this.linkLabel9.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkContacts_LinkClicked);
            // 
            // buttonShodan
            // 
            this.buttonShodan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonShodan.Image = ((System.Drawing.Image)(resources.GetObject("buttonShodan.Image")));
            this.buttonShodan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonShodan.Location = new System.Drawing.Point(424, 102);
            this.buttonShodan.Name = "buttonShodan";
            this.buttonShodan.Size = new System.Drawing.Size(73, 23);
            this.buttonShodan.TabIndex = 96;
            this.buttonShodan.Text = "&Shodan";
            this.buttonShodan.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonShodan.UseVisualStyleBackColor = true;
            this.buttonShodan.Click += new System.EventHandler(this.buttonShodan_Click);
            // 
            // linkLabel8
            // 
            this.linkLabel8.AutoSize = true;
            this.linkLabel8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel8.Location = new System.Drawing.Point(291, 107);
            this.linkLabel8.Name = "linkLabel8";
            this.linkLabel8.Size = new System.Drawing.Size(86, 13);
            this.linkLabel8.TabIndex = 95;
            this.linkLabel8.TabStop = true;
            this.linkLabel8.Tag = "jmath@surtri.com";
            this.linkLabel8.Text = "John C. Matherly";
            this.linkLabel8.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkContacts_LinkClicked);
            // 
            // labelBuild
            // 
            this.labelBuild.AutoSize = true;
            this.labelBuild.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBuild.Location = new System.Drawing.Point(93, 157);
            this.labelBuild.Name = "labelBuild";
            this.labelBuild.Size = new System.Drawing.Size(23, 13);
            this.labelBuild.TabIndex = 102;
            this.labelBuild.Text = "x.x";
            // 
            // labelBuildl
            // 
            this.labelBuildl.AutoSize = true;
            this.labelBuildl.Location = new System.Drawing.Point(39, 157);
            this.labelBuildl.Name = "labelBuildl";
            this.labelBuildl.Size = new System.Drawing.Size(36, 13);
            this.labelBuildl.TabIndex = 101;
            this.labelBuildl.Text = "Build: ";
            // 
            // labelVersion
            // 
            this.labelVersion.AutoSize = true;
            this.labelVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVersion.Location = new System.Drawing.Point(93, 135);
            this.labelVersion.Name = "labelVersion";
            this.labelVersion.Size = new System.Drawing.Size(23, 13);
            this.labelVersion.TabIndex = 100;
            this.labelVersion.Text = "x.x";
            // 
            // labelVersionl
            // 
            this.labelVersionl.AutoSize = true;
            this.labelVersionl.Location = new System.Drawing.Point(39, 135);
            this.labelVersionl.Name = "labelVersionl";
            this.labelVersionl.Size = new System.Drawing.Size(48, 13);
            this.labelVersionl.TabIndex = 99;
            this.labelVersionl.Text = "Version: ";
            // 
            // linkLabel7
            // 
            this.linkLabel7.AutoSize = true;
            this.linkLabel7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel7.Location = new System.Drawing.Point(291, 23);
            this.linkLabel7.Name = "linkLabel7";
            this.linkLabel7.Size = new System.Drawing.Size(148, 13);
            this.linkLabel7.TabIndex = 89;
            this.linkLabel7.TabStop = true;
            this.linkLabel7.Tag = "manuel.fernandez@11paths.com";
            this.linkLabel7.Text = "Manuel Fernández Fernández";
            this.linkLabel7.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkContacts_LinkClicked);
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel6.Location = new System.Drawing.Point(291, 65);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(106, 13);
            this.linkLabel6.TabIndex = 91;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Tag = "plaguna@informatica64.com";
            this.linkLabel6.Text = "Pedro Laguna Durán";
            this.linkLabel6.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkContacts_LinkClicked);
            // 
            // linkLabel5
            // 
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel5.Location = new System.Drawing.Point(291, 128);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(123, 13);
            this.linkLabel5.TabIndex = 93;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Tag = "froca@informatica64.com";
            this.linkLabel5.Text = "Francisco Oca González";
            this.linkLabel5.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkContacts_LinkClicked);
            // 
            // lblResearchers
            // 
            this.lblResearchers.AutoSize = true;
            this.lblResearchers.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblResearchers.Location = new System.Drawing.Point(160, 2);
            this.lblResearchers.Name = "lblResearchers";
            this.lblResearchers.Size = new System.Drawing.Size(116, 13);
            this.lblResearchers.TabIndex = 98;
            this.lblResearchers.Text = "Authors && Collaborators";
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel3.Location = new System.Drawing.Point(291, 44);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(132, 13);
            this.linkLabel3.TabIndex = 90;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Tag = "Antonio.guzman@11paths.com";
            this.linkLabel3.Text = "Antonio Guzmán Sacristán";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkContacts_LinkClicked);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel2.Location = new System.Drawing.Point(291, 149);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(125, 13);
            this.linkLabel2.TabIndex = 94;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Tag = "enrique.rando@juntadeandalucia.es";
            this.linkLabel2.Text = "Enrique Rando González";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkContacts_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel1.Location = new System.Drawing.Point(291, 2);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(114, 13);
            this.linkLabel1.TabIndex = 88;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Tag = "chema@11paths.com";
            this.linkLabel1.Text = "Chema Alonso Cebrián";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkContacts_LinkClicked);
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.linkLabel4.Location = new System.Drawing.Point(291, 86);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(117, 13);
            this.linkLabel4.TabIndex = 92;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Tag = "amartin@informatica64.com";
            this.linkLabel4.Text = "Alejandro Martín Bailón";
            this.linkLabel4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkContacts_LinkClicked);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.AutoSize = true;
            this.panel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel3.Location = new System.Drawing.Point(163, 54);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(0, 0);
            this.panel3.TabIndex = 97;
            // 
            // textBoxLicence
            // 
            this.textBoxLicence.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxLicence.Location = new System.Drawing.Point(12, 227);
            this.textBoxLicence.Multiline = true;
            this.textBoxLicence.Name = "textBoxLicence";
            this.textBoxLicence.ReadOnly = true;
            this.textBoxLicence.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxLicence.Size = new System.Drawing.Size(489, 107);
            this.textBoxLicence.TabIndex = 1;
            this.textBoxLicence.Text = resources.GetString("textBoxLicence.Text");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 211);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 88;
            this.label1.Text = "License:";
            // 
            // picAbout
            // 
            this.picAbout.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.picAbout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picAbout.Image = global::FOCA.Properties.Resources.logocontexto_negro;
            this.picAbout.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.picAbout.Location = new System.Drawing.Point(167, 451);
            this.picAbout.Name = "picAbout";
            this.picAbout.Size = new System.Drawing.Size(182, 58);
            this.picAbout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAbout.TabIndex = 76;
            this.picAbout.TabStop = false;
            this.picAbout.Click += new System.EventHandler(this.picAbout_Click);
            // 
            // FormAbout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 513);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.picAbout);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(842, 681);
            this.MinimumSize = new System.Drawing.Size(513, 489);
            this.Name = "FormAbout";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "About";
            this.Load += new System.EventHandler(this.FormAbout_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAdvert)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panelInfo.ResumeLayout(false);
            this.panelInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFOCA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAbout)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBoxLicence;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picAbout;
        private System.Windows.Forms.Panel panelInfo;
        private System.Windows.Forms.PictureBox picFOCA;
        private System.Windows.Forms.LinkLabel linkLabel9;
        private System.Windows.Forms.Button buttonShodan;
        private System.Windows.Forms.LinkLabel linkLabel8;
        private System.Windows.Forms.Label labelBuild;
        private System.Windows.Forms.Label labelBuildl;
        private System.Windows.Forms.Label labelVersion;
        private System.Windows.Forms.Label labelVersionl;
        private System.Windows.Forms.LinkLabel linkLabel7;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.Label lblResearchers;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.PictureBox pictureBoxAdvert;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.LinkLabel linkLabel10;

    }
}